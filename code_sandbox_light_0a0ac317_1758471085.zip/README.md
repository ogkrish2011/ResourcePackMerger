# 🎮 ResourceCraft - Minecraft Resource Pack Merger

A beautiful, modern web application for combining multiple Minecraft resource packs into a single merged pack with a stunning Minecraft-themed aesthetic design.

## ✨ Features

### Currently Implemented Features

#### 🔄 **Core Functionality**
- **Drag & Drop Upload**: Intuitive drag-and-drop interface for uploading multiple .zip resource packs
- **File Size Warning**: Smart warning system for files over 75MB (warns but doesn't block)
- **Resource Pack Merging**: Intelligent merging algorithm that combines multiple packs
- **Automatic Download**: Instant download of merged resource pack as .zip file
- **Conflict Resolution**: Later packs override earlier ones for conflicting files

#### 🎨 **Pack Customization**
- **Custom Icon**: Upload and set custom pack icon (pack.png)
- **Pack Name**: Customize the name of your merged resource pack
- **Pack Description**: Add detailed description for your merged pack
- **Metadata Generation**: Automatic pack.mcmeta creation with proper format

#### 🎭 **User Interface**
- **Minecraft-Themed Design**: Authentic Minecraft aesthetic with pixel-perfect styling
- **Animated Elements**: Smooth animations, floating icons, and interactive effects
- **Real-time Progress**: Live progress tracking during merge operations
- **File Management**: Add/remove files with visual feedback
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile devices

#### 🚀 **Advanced Features**
- **No File Size Limit**: Upload packs of any size (with performance warnings)
- **Multiple File Support**: Merge unlimited number of resource packs
- **Error Handling**: Robust error handling with user-friendly notifications
- **Performance Optimization**: Efficient file processing and memory management
- **Easter Egg**: Hidden Konami code for color inversion effect

## 🛠 Technical Implementation

### File Structure
```
📁 ResourceCraft/
├── 📄 index.html          # Main HTML structure
├── 📁 css/
│   └── 📄 style.css       # Minecraft-themed styles
├── 📁 js/
│   └── 📄 main.js         # Core functionality
└── 📄 README.md           # Documentation
```

### Dependencies
- **JSZip v3.10.1**: ZIP file creation and manipulation
- **Font Awesome v6.4.0**: Icons and visual elements
- **Google Fonts**: Orbitron & Roboto font families

### Browser Compatibility
- ✅ Chrome 80+
- ✅ Firefox 75+
- ✅ Safari 13+
- ✅ Edge 80+

## 🎯 How to Use

### 1. **Upload Resource Packs**
- Drag and drop .zip resource pack files onto the upload zone
- Or click "Browse Files" to select files manually
- Files over 75MB will show a warning (but can still be processed)

### 2. **Customize Your Pack**
- Click on the pack icon to upload a custom image
- Edit the pack name and description in the editor section
- Preview your changes in real-time

### 3. **Merge & Download**
- Click "Merge & Download" button to start the process
- Watch the progress bar as files are processed
- Your merged pack will automatically download when complete

### 4. **Install in Minecraft**
- Place the downloaded .zip file in your Minecraft resource packs folder
- Activate it in Minecraft's Resource Packs settings

## 🔧 Technical Details

### Merge Algorithm
1. **File Loading**: All uploaded ZIP files are loaded into memory
2. **Conflict Resolution**: Files with same paths are resolved (last pack wins)
3. **Metadata Creation**: New pack.mcmeta is generated with user settings
4. **Icon Processing**: Custom icon is converted and embedded
5. **ZIP Generation**: Final merged pack is created with DEFLATE compression
6. **Auto Download**: Browser automatically downloads the result

### Performance Considerations
- **Memory Management**: Large files are processed in chunks
- **Progress Updates**: UI updates every 50 files during processing
- **Compression**: Optimized ZIP compression for smaller file sizes
- **Error Recovery**: Graceful handling of corrupted or invalid files

## 🎨 Design Features

### Visual Elements
- **Minecraft Color Palette**: Authentic green, blue, and brown tones
- **Pixelated Aesthetic**: Blocky, pixel-perfect design elements
- **Animated Background**: Subtle floating grid pattern
- **Glowing Effects**: Neon-style borders and shadows
- **Hover Animations**: Interactive elements with smooth transitions

### Typography
- **Orbitron**: Futuristic font for headings and buttons
- **Roboto**: Clean, readable font for body text
- **Font Awesome**: Vector icons for visual enhancement

## 🚫 Current Limitations

### File Format Support
- Only supports .zip resource pack files
- Does not validate internal resource pack structure
- Cannot merge .jar or other Minecraft mod formats

### Merge Behavior
- Simple file override (no smart texture blending)
- No conflict detection or resolution options
- Cannot selectively choose files from each pack

### Browser Limitations
- Large files may cause memory issues in older browsers
- No server-side processing (purely client-side)
- Download size limited by browser memory

## 🔮 Recommended Next Steps

### High Priority Enhancements
1. **Pack Validation**: Validate resource pack structure and compatibility
2. **Selective Merging**: Choose specific files/folders from each pack
3. **Conflict Detection**: Show conflicts and resolution options
4. **Format Support**: Add support for .mcpack and other formats

### Medium Priority Features
1. **Pack Preview**: Visual preview of textures and models
2. **Version Compatibility**: Check and convert between pack formats
3. **Backup System**: Save merge configurations for later use
4. **Batch Processing**: Process multiple merge operations

### Low Priority Additions
1. **Cloud Storage**: Save packs to cloud storage services
2. **Sharing System**: Share merged packs with other users
3. **Statistics**: Show detailed merge statistics and file counts
4. **Themes**: Multiple UI themes beyond Minecraft style

## 🎮 Easter Eggs

### Konami Code
Press the classic Konami code sequence to activate a special color inversion effect:
**↑ ↑ ↓ ↓ ← → ← → B A**

## 💻 Development Notes

### Code Structure
- **Object-Oriented Design**: Main functionality wrapped in `ResourcePackMerger` class
- **Event-Driven Architecture**: Modular event handling for UI interactions
- **Async/Await Pattern**: Modern JavaScript for file processing
- **Error Boundaries**: Comprehensive error handling throughout

### Performance Optimizations
- **File Chunking**: Large operations split into manageable chunks
- **Memory Cleanup**: Proper cleanup of file objects and URLs
- **Progressive Loading**: UI updates during long operations
- **Compression Settings**: Balanced compression for speed/size ratio

## 🌟 Project Goals

**ResourceCraft** aims to be the ultimate tool for Minecraft resource pack enthusiasts, providing:
- **Simplicity**: Easy-to-use interface for all skill levels
- **Power**: Advanced merging capabilities for complex packs
- **Beauty**: Stunning Minecraft-themed visual design
- **Performance**: Fast, efficient processing even for large files
- **Reliability**: Robust error handling and recovery

---

**Made with ❤️ for the Minecraft community**

*ResourceCraft - Where creativity meets functionality in the world of Minecraft resource packs!*