import JSZip from 'jszip'

export class PackMerger {
  constructor() {
    this.conflictResolutions = new Map()
  }

  async analyzeConflicts(packs, progressCallback = null) {
    if (packs.length < 2) return []

    const conflicts = []
    const fileMap = new Map() // path -> [{ packId, packName, packIcon, fileSize, lastModified }]

    // Build file map
    for (let i = 0; i < packs.length; i++) {
      const pack = packs[i]
      
      if (progressCallback) {
        progressCallback(i + 1, packs.length, `Analyzing ${pack.name}...`)
      }

      for (const filePath of Object.keys(pack.files)) {
        if (!fileMap.has(filePath)) {
          fileMap.set(filePath, [])
        }

        const fileSize = this.getFileSize(pack.files[filePath])
        
        fileMap.get(filePath).push({
          packId: pack.id,
          packName: pack.name,
          packIcon: pack.icon,
          fileSize,
          lastModified: pack.originalFile?.lastModified || Date.now()
        })
      }
    }

    // Find conflicts (files that exist in multiple packs)
    for (const [filePath, packInfos] of fileMap) {
      if (packInfos.length > 1) {
        conflicts.push({
          path: filePath,
          packs: packInfos,
          preview: await this.getFilePreview(filePath, packs, packInfos[0].packId)
        })
      }
    }

    return conflicts
  }

  async getFilePreview(filePath, packs, packId) {
    try {
      const pack = packs.find(p => p.id === packId)
      if (!pack || !pack.files[filePath]) return null

      const content = pack.files[filePath]
      
      // For text files, return a preview
      if (typeof content === 'string') {
        return content.slice(0, 500) + (content.length > 500 ? '...' : '')
      }
      
      // For binary files, return file info
      const size = content.byteLength || content.length || 0
      return `Binary file (${(size / 1024).toFixed(1)} KB)`
      
    } catch (error) {
      return `Error reading file: ${error.message}`
    }
  }

  getFileSize(content) {
    if (typeof content === 'string') {
      return new Blob([content]).size
    }
    if (content instanceof ArrayBuffer) {
      return content.byteLength
    }
    if (content && content.length !== undefined) {
      return content.length
    }
    return 0
  }

  setConflictResolutions(resolutions) {
    this.conflictResolutions.clear()
    for (const [filePath, packId] of Object.entries(resolutions)) {
      this.conflictResolutions.set(filePath, packId)
    }
  }

  async mergePacks(packs, progressCallback = null) {
    if (packs.length === 0) {
      throw new Error('No packs to merge')
    }

    if (packs.length === 1) {
      // Single pack, just return it
      return this.prepareSinglePackForEditor(packs[0])
    }

    const mergedFiles = new Map()
    const mergedData = {
      name: 'Merged Pack',
      description: 'A merged resource pack created with Pack Merger',
      type: this.determineMergedPackType(packs),
      format: this.determineMergedPackFormat(packs),
      minEngineVersion: this.determineMergedMinEngineVersion(packs),
      icon: null,
      iconData: null,
      files: {},
      size: 0,
      fileCount: 0
    }

    let processedFiles = 0
    let totalFiles = 0

    // Calculate total files for progress
    for (const pack of packs) {
      totalFiles += Object.keys(pack.files).length
    }

    // Merge files with priority (first pack wins for conflicts)
    for (let packIndex = 0; packIndex < packs.length; packIndex++) {
      const pack = packs[packIndex]
      
      if (progressCallback) {
        progressCallback(
          packIndex + 1, 
          packs.length, 
          `Merging ${pack.name}...`
        )
      }

      // Set icon from first pack if not already set
      if (!mergedData.icon && pack.icon) {
        mergedData.icon = pack.icon
        
        // Also extract icon data for download
        const iconPath = pack.type === 'bedrock' ? 'pack_icon.png' : 'pack.png'
        if (pack.files[iconPath]) {
          mergedData.iconData = pack.files[iconPath]
        }
      }

      // Process each file in the pack
      for (const [filePath, fileContent] of Object.entries(pack.files)) {
        processedFiles++

        // Skip metadata files - we'll generate new ones
        if (filePath === 'pack.mcmeta' || filePath === 'manifest.json') {
          continue
        }

        // Check if this file already exists (conflict)
        if (mergedFiles.has(filePath)) {
          // Use conflict resolution if available
          const resolvedPackId = this.conflictResolutions.get(filePath)
          
          if (resolvedPackId && resolvedPackId === pack.id) {
            // This pack's version should override
            mergedFiles.set(filePath, {
              content: fileContent,
              packId: pack.id,
              packName: pack.name
            })
          }
          // Otherwise, keep the existing (higher priority) version
        } else {
          // No conflict, add the file
          mergedFiles.set(filePath, {
            content: fileContent,
            packId: pack.id,
            packName: pack.name
          })
        }

        // Update progress occasionally to prevent UI blocking
        if (processedFiles % 100 === 0 && progressCallback) {
          progressCallback(
            packIndex + 1, 
            packs.length, 
            `Processing files... (${processedFiles}/${totalFiles})`
          )
        }
      }
    }

    // Convert merged files to final format
    for (const [filePath, fileData] of mergedFiles) {
      mergedData.files[filePath] = fileData.content
      mergedData.size += this.getFileSize(fileData.content)
    }

    mergedData.fileCount = mergedFiles.size

    return mergedData
  }

  determineMergedPackType(packs) {
    // If all packs are the same type, use that type
    const types = [...new Set(packs.map(pack => pack.type))]
    
    if (types.length === 1) {
      return types[0]
    }
    
    // Mixed types - count each type and use the most common
    const typeCounts = {}
    for (const pack of packs) {
      typeCounts[pack.type] = (typeCounts[pack.type] || 0) + 1
    }
    
    return Object.keys(typeCounts).reduce((a, b) => 
      typeCounts[a] > typeCounts[b] ? a : b
    )
  }

  determineMergedPackFormat(packs) {
    // Use the highest format version found
    let maxFormat = 1
    
    for (const pack of packs) {
      if (pack.format && pack.format > maxFormat) {
        maxFormat = pack.format
      }
    }
    
    return maxFormat
  }

  determineMergedMinEngineVersion(packs) {
    // Use the highest engine version found
    let maxVersion = [1, 16, 0]
    
    for (const pack of packs) {
      if (pack.minEngineVersion && this.compareVersions(pack.minEngineVersion, maxVersion) > 0) {
        maxVersion = pack.minEngineVersion
      }
    }
    
    return maxVersion
  }

  compareVersions(a, b) {
    for (let i = 0; i < Math.max(a.length, b.length); i++) {
      const aVal = a[i] || 0
      const bVal = b[i] || 0
      
      if (aVal > bVal) return 1
      if (aVal < bVal) return -1
    }
    
    return 0
  }

  prepareSinglePackForEditor(pack) {
    return {
      name: pack.name,
      description: 'Resource pack processed with Pack Merger',
      type: pack.type,
      format: pack.format,
      minEngineVersion: pack.minEngineVersion,
      icon: pack.icon,
      iconData: pack.files[pack.type === 'bedrock' ? 'pack_icon.png' : 'pack.png'] || null,
      files: { ...pack.files },
      size: pack.size,
      fileCount: pack.fileCount
    }
  }

  // Utility method to validate pack compatibility
  validatePackCompatibility(packs) {
    const issues = []
    
    // Check for type mixing
    const types = [...new Set(packs.map(pack => pack.type))]
    if (types.length > 1) {
      issues.push({
        type: 'warning',
        message: `Mixed pack types detected: ${types.join(', ')}. The merged pack will use the most common type.`
      })
    }
    
    // Check for format version differences
    const formats = packs.map(pack => pack.format).filter(f => f != null)
    if (formats.length > 1) {
      const minFormat = Math.min(...formats)
      const maxFormat = Math.max(...formats)
      
      if (maxFormat - minFormat > 2) {
        issues.push({
          type: 'warning',
          message: `Large format version difference detected (${minFormat} to ${maxFormat}). Some features may not work correctly.`
        })
      }
    }
    
    return issues
  }

  // Clean up resources
  dispose() {
    this.conflictResolutions.clear()
  }
}