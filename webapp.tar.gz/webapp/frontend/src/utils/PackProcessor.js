import JSZip from 'jszip'

export class PackProcessor {
  constructor() {
    this.supportedExtensions = ['.zip', '.mcpack']
  }

  async processPackFile(file) {
    if (!this.isValidPackFile(file)) {
      throw new Error(`Unsupported file type. Please use ${this.supportedExtensions.join(', ')} files.`)
    }

    try {
      const zip = await JSZip.loadAsync(file)
      const packData = await this.extractPackData(zip, file.name)
      
      return {
        ...packData,
        originalFile: file
      }
    } catch (error) {
      throw new Error(`Failed to read pack file: ${error.message}`)
    }
  }

  isValidPackFile(file) {
    return this.supportedExtensions.some(ext => 
      file.name.toLowerCase().endsWith(ext)
    )
  }

  async extractPackData(zip, fileName) {
    const files = {}
    let packType = 'unknown'
    let packFormat = null
    let minEngineVersion = null
    let packName = fileName.replace(/\.(zip|mcpack)$/i, '')
    let packDescription = ''
    let packIcon = null

    // First pass: identify pack type and extract metadata
    const manifestFile = zip.file('manifest.json')
    const mcmetaFile = zip.file('pack.mcmeta')

    if (manifestFile) {
      // Bedrock pack
      packType = 'bedrock'
      try {
        const manifestContent = await manifestFile.async('string')
        const manifest = JSON.parse(manifestContent)
        
        if (manifest.header) {
          packName = manifest.header.name || packName
          packDescription = manifest.header.description || ''
          
          if (manifest.header.min_engine_version) {
            minEngineVersion = manifest.header.min_engine_version
            packFormat = manifest.header.min_engine_version[1] || 1
          }
        }
      } catch (error) {
        console.warn('Failed to parse manifest.json:', error)
      }
    } else if (mcmetaFile) {
      // Java pack
      packType = 'java'
      try {
        const mcmetaContent = await mcmetaFile.async('string')
        const mcmeta = JSON.parse(mcmetaContent)
        
        if (mcmeta.pack) {
          packFormat = mcmeta.pack.pack_format
          packDescription = Array.isArray(mcmeta.pack.description) 
            ? mcmeta.pack.description.join(' ')
            : (mcmeta.pack.description || '')
        }
      } catch (error) {
        console.warn('Failed to parse pack.mcmeta:', error)
      }
    }

    // Extract icon
    const iconFile = zip.file('pack_icon.png') || zip.file('pack.png')
    if (iconFile) {
      try {
        const iconBlob = await iconFile.async('blob')
        packIcon = URL.createObjectURL(iconBlob)
      } catch (error) {
        console.warn('Failed to extract pack icon:', error)
      }
    }

    // Second pass: extract all files
    const filePromises = []
    
    zip.forEach((relativePath, zipEntry) => {
      // Skip directories and Mac metadata
      if (zipEntry.dir || relativePath.includes('__MACOSX')) {
        return
      }

      filePromises.push(
        this.processZipEntry(relativePath, zipEntry)
          .then(result => {
            if (result) {
              files[relativePath] = result
            }
          })
          .catch(error => {
            console.warn(`Failed to process file ${relativePath}:`, error)
          })
      )
    })

    await Promise.all(filePromises)

    // Validate pack structure
    if (Object.keys(files).length === 0) {
      throw new Error('No valid files found in pack')
    }

    // Auto-detect type if not found from metadata
    if (packType === 'unknown') {
      packType = this.detectPackType(files)
    }

    return {
      name: packName,
      description: packDescription,
      type: packType,
      format: packFormat,
      minEngineVersion,
      icon: packIcon,
      files,
      metadata: {
        hasManifest: !!manifestFile,
        hasMcmeta: !!mcmetaFile,
        detectedType: packType
      }
    }
  }

  async processZipEntry(path, zipEntry) {
    try {
      // For text files, read as string
      if (this.isTextFile(path)) {
        return await zipEntry.async('string')
      }
      
      // For binary files, read as array buffer
      return await zipEntry.async('arraybuffer')
      
    } catch (error) {
      console.warn(`Failed to read file ${path}:`, error)
      return null
    }
  }

  isTextFile(path) {
    const textExtensions = [
      '.json', '.mcmeta', '.txt', '.md', '.lang', '.properties',
      '.cfg', '.ini', '.yml', '.yaml', '.xml', '.js', '.css',
      '.glsl', '.vsh', '.fsh', '.vert', '.frag'
    ]
    
    const ext = '.' + path.split('.').pop().toLowerCase()
    return textExtensions.includes(ext)
  }

  detectPackType(files) {
    // Check for Bedrock-specific files
    const bedrockIndicators = [
      'manifest.json',
      'pack_icon.png',
      'texts/en_US.lang',
      'texts/languages.json'
    ]

    // Check for Java-specific files
    const javaIndicators = [
      'pack.mcmeta',
      'pack.png',
      'assets/minecraft/',
      'data/'
    ]

    const hasBedrockFiles = bedrockIndicators.some(indicator =>
      Object.keys(files).some(path => path.includes(indicator))
    )

    const hasJavaFiles = javaIndicators.some(indicator =>
      Object.keys(files).some(path => path.includes(indicator))
    )

    if (hasBedrockFiles && !hasJavaFiles) return 'bedrock'
    if (hasJavaFiles && !hasBedrockFiles) return 'java'
    
    // If both or neither, default to java
    return 'java'
  }

  normalizeManifest(manifest) {
    // Ensure manifest has required fields with valid UUIDs
    const normalized = {
      format_version: 2,
      ...manifest
    }

    if (!normalized.header) {
      normalized.header = {}
    }

    // Generate new UUIDs if missing or invalid
    if (!this.isValidUUID(normalized.header.uuid)) {
      normalized.header.uuid = this.generateUUID()
    }

    if (!normalized.header.version) {
      normalized.header.version = [1, 0, 0]
    }

    if (!normalized.header.min_engine_version) {
      normalized.header.min_engine_version = [1, 16, 0]
    }

    if (!normalized.modules) {
      normalized.modules = []
    }

    // Ensure resources module exists
    let resourcesModule = normalized.modules.find(m => m.type === 'resources')
    if (!resourcesModule) {
      resourcesModule = {
        type: 'resources',
        uuid: this.generateUUID(),
        version: [1, 0, 0]
      }
      normalized.modules.push(resourcesModule)
    } else if (!this.isValidUUID(resourcesModule.uuid)) {
      resourcesModule.uuid = this.generateUUID()
    }

    return normalized
  }

  normalizeMcmeta(mcmeta) {
    const normalized = {
      pack: {
        pack_format: 15, // Default to latest known format
        description: '',
        ...mcmeta.pack
      }
    }

    // Ensure description is a string
    if (Array.isArray(normalized.pack.description)) {
      normalized.pack.description = normalized.pack.description
        .map(desc => typeof desc === 'string' ? desc : JSON.stringify(desc))
        .join(' ')
    }

    return normalized
  }

  isValidUUID(uuid) {
    if (!uuid || typeof uuid !== 'string') return false
    
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
    return uuidRegex.test(uuid)
  }

  generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0
      const v = c === 'x' ? r : (r & 0x3 | 0x8)
      return v.toString(16)
    })
  }
}