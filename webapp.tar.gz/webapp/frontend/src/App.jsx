import React, { useState, useCallback } from 'react'
import { Toaster } from 'react-hot-toast'
import Header from './components/Header'
import UploadZone from './components/UploadZone'
import PackList from './components/PackList'
import PackEditor from './components/PackEditor'
import ConflictResolver from './components/ConflictResolver'
import ProgressModal from './components/ProgressModal'
import { useTheme } from './hooks/useTheme'
import { usePackMerger } from './hooks/usePackMerger'

function App() {
  const { isDark, toggleTheme } = useTheme()
  const {
    packs,
    conflicts,
    isProcessing,
    progress,
    addPacks,
    removePack,
    reorderPacks,
    resolveConflicts,
    mergePacks,
    resetMerger
  } = usePackMerger()

  const [showEditor, setShowEditor] = useState(false)
  const [showConflicts, setShowConflicts] = useState(false)
  const [mergedPackData, setMergedPackData] = useState(null)

  const handleFilesAdded = useCallback(async (files) => {
    try {
      await addPacks(files)
    } catch (error) {
      console.error('Error adding packs:', error)
    }
  }, [addPacks])

  const handleMergePacks = useCallback(async () => {
    if (conflicts.length > 0) {
      setShowConflicts(true)
      return
    }
    
    try {
      const result = await mergePacks()
      setMergedPackData(result)
      setShowEditor(true)
    } catch (error) {
      console.error('Error merging packs:', error)
    }
  }, [mergePacks, conflicts])

  const handleConflictsResolved = useCallback(async (resolutions) => {
    try {
      await resolveConflicts(resolutions)
      setShowConflicts(false)
      const result = await mergePacks()
      setMergedPackData(result)
      setShowEditor(true)
    } catch (error) {
      console.error('Error after resolving conflicts:', error)
    }
  }, [resolveConflicts, mergePacks])

  const handleEditorClose = useCallback(() => {
    setShowEditor(false)
    setMergedPackData(null)
  }, [])

  const handleReset = useCallback(() => {
    resetMerger()
    setShowEditor(false)
    setShowConflicts(false)
    setMergedPackData(null)
  }, [resetMerger])

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDark ? 'dark' : ''}`}>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
        <Header isDark={isDark} toggleTheme={toggleTheme} />
        
        <main className="container mx-auto px-4 py-8">
          <div className="max-w-6xl mx-auto space-y-8">
            {/* Hero Section */}
            <div className="text-center space-y-4 animate-fade-in">
              <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Minecraft Pack Merger
              </h1>
              <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                Combine multiple resource packs with advanced conflict resolution, 
                built-in editor, and automatic manifest normalization.
              </p>
            </div>

            {/* Upload Zone */}
            {packs.length === 0 && (
              <div className="animate-slide-up">
                <UploadZone onFilesAdded={handleFilesAdded} />
              </div>
            )}

            {/* Pack Management */}
            {packs.length > 0 && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-fade-in">
                <div className="lg:col-span-2 space-y-6">
                  <PackList
                    packs={packs}
                    onRemovePack={removePack}
                    onReorderPacks={reorderPacks}
                    onAddMore={handleFilesAdded}
                  />
                </div>
                
                <div className="space-y-6">
                  <div className="card p-6">
                    <h3 className="text-xl font-semibold mb-4">Merge Options</h3>
                    
                    <div className="space-y-4">
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        <p><strong>{packs.length}</strong> packs ready to merge</p>
                        {conflicts.length > 0 && (
                          <p className="text-amber-600 dark:text-amber-400">
                            <strong>{conflicts.length}</strong> conflicts detected
                          </p>
                        )}
                      </div>
                      
                      <button
                        onClick={handleMergePacks}
                        disabled={packs.length < 2 || isProcessing}
                        className="w-full btn-primary"
                      >
                        {conflicts.length > 0 ? 'Review Conflicts' : 'Merge Packs'}
                      </button>
                      
                      <button
                        onClick={handleReset}
                        className="w-full btn-secondary"
                      >
                        Reset All
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>

        {/* Modals */}
        {showConflicts && (
          <ConflictResolver
            conflicts={conflicts}
            onResolve={handleConflictsResolved}
            onCancel={() => setShowConflicts(false)}
          />
        )}

        {showEditor && mergedPackData && (
          <PackEditor
            packData={mergedPackData}
            onClose={handleEditorClose}
          />
        )}

        {isProcessing && (
          <ProgressModal progress={progress} />
        )}

        <Toaster
          position="bottom-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: isDark ? '#374151' : '#ffffff',
              color: isDark ? '#f3f4f6' : '#111827',
              border: `1px solid ${isDark ? '#4B5563' : '#e5e7eb'}`,
            },
          }}
        />
      </div>
    </div>
  )
}

export default App