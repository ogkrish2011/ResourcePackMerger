import React from 'react'

const ProgressModal = ({ progress }) => {
  const { phase, current, total, message, percentage } = progress

  const getPhaseIcon = (phase) => {
    switch (phase) {
      case 'uploading':
        return (
          <svg className="w-8 h-8 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
          </svg>
        )
      case 'reading':
        return (
          <svg className="w-8 h-8 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
          </svg>
        )
      case 'analyzing':
        return (
          <svg className="w-8 h-8 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>
          </svg>
        )
      case 'merging':
        return (
          <svg className="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
          </svg>
        )
      case 'generating':
        return (
          <svg className="w-8 h-8 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
          </svg>
        )
      default:
        return (
          <svg className="w-8 h-8 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
          </svg>
        )
    }
  }

  const getPhaseTitle = (phase) => {
    switch (phase) {
      case 'uploading':
        return 'Uploading Packs'
      case 'reading':
        return 'Reading Pack Contents'
      case 'analyzing':
        return 'Analyzing Conflicts'
      case 'merging':
        return 'Merging Packs'
      case 'generating':
        return 'Generating Final Pack'
      default:
        return 'Processing...'
    }
  }

  const getPhaseDescription = (phase) => {
    switch (phase) {
      case 'uploading':
        return 'Uploading and validating resource pack files'
      case 'reading':
        return 'Extracting and reading pack contents'
      case 'analyzing':
        return 'Detecting file conflicts and dependencies'
      case 'merging':
        return 'Combining packs with conflict resolution'
      case 'generating':
        return 'Creating final merged pack archive'
      default:
        return 'Please wait while we process your packs'
    }
  }

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex min-h-screen items-center justify-center p-4">
        {/* Backdrop */}
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm" />
        
        {/* Modal */}
        <div className="relative w-full max-w-md bg-white dark:bg-gray-800 rounded-xl shadow-2xl animate-slide-up">
          <div className="p-8">
            {/* Icon and Title */}
            <div className="text-center mb-6">
              <div className="flex justify-center mb-4">
                <div className="animate-pulse">
                  {getPhaseIcon(phase)}
                </div>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                {getPhaseTitle(phase)}
              </h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                {getPhaseDescription(phase)}
              </p>
            </div>

            {/* Progress Bar */}
            <div className="mb-6">
              <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400 mb-2">
                <span>{message || 'Processing...'}</span>
                <span>{percentage}%</span>
              </div>
              
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3 overflow-hidden">
                <div 
                  className="progress-bar h-full rounded-full transition-all duration-300 ease-out"
                  style={{ width: `${percentage}%` }}
                />
              </div>
              
              {total > 0 && (
                <div className="text-center text-xs text-gray-500 dark:text-gray-400 mt-2">
                  {current} of {total} files processed
                </div>
              )}
            </div>

            {/* Loading Animation */}
            <div className="flex justify-center">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
              </div>
            </div>

            {/* Tips */}
            <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <div className="flex items-start space-x-2">
                <svg className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd"/>
                </svg>
                <div className="text-sm">
                  <p className="text-blue-800 dark:text-blue-200 font-medium mb-1">
                    Pro Tip
                  </p>
                  <p className="text-blue-700 dark:text-blue-300">
                    {phase === 'analyzing' && 'We\'re checking for file conflicts to ensure the best merge quality.'}
                    {phase === 'reading' && 'Large packs may take longer to process. This ensures all files are properly handled.'}
                    {phase === 'merging' && 'Your packs are being combined while preserving the priority order you set.'}
                    {phase === 'generating' && 'Creating the final archive with optimized file structure and metadata.'}
                    {!['analyzing', 'reading', 'merging', 'generating'].includes(phase) && 'The merge process ensures compatibility and resolves conflicts automatically.'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ProgressModal