import React, { useState, useRef, useCallback } from 'react'
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd'
import toast from 'react-hot-toast'

const PackItem = ({ pack, index, onRemove }) => {
  return (
    <Draggable draggableId={pack.id} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          className={`card p-4 transition-all duration-200 ${
            snapshot.isDragging 
              ? 'shadow-2xl rotate-2 scale-105' 
              : 'hover:shadow-md'
          }`}
        >
          <div className="flex items-center space-x-4">
            {/* Drag Handle */}
            <div
              {...provided.dragHandleProps}
              className="flex-shrink-0 p-2 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300 cursor-grab active:cursor-grabbing"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 16a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z"/>
              </svg>
            </div>

            {/* Pack Icon */}
            <div className="flex-shrink-0">
              {pack.icon ? (
                <img
                  src={pack.icon}
                  alt={`${pack.name} icon`}
                  className="w-12 h-12 rounded-lg object-cover shadow-sm"
                />
              ) : (
                <div className="w-12 h-12 bg-gradient-to-br from-gray-400 to-gray-600 rounded-lg flex items-center justify-center shadow-sm">
                  <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h6a1 1 0 110 2H4a1 1 0 01-1-1zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z" clipRule="evenodd"/>
                  </svg>
                </div>
              )}
            </div>

            {/* Pack Info */}
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-gray-900 dark:text-white truncate">
                {pack.name}
              </h4>
              <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400 mt-1">
                <span>{pack.fileCount} files</span>
                <span>{(pack.size / 1024 / 1024).toFixed(1)} MB</span>
                <span className={`px-2 py-1 rounded-full text-xs ${
                  pack.type === 'java' 
                    ? 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200' 
                    : 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                }`}>
                  {pack.type === 'java' ? 'Java' : 'Bedrock'}
                </span>
                {pack.format && (
                  <span className="text-xs text-gray-400 dark:text-gray-500">
                    v{pack.format}
                  </span>
                )}
              </div>
            </div>

            {/* Priority Badge */}
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full flex items-center justify-center text-sm font-medium">
                {index + 1}
              </div>
            </div>

            {/* Remove Button */}
            <button
              onClick={() => onRemove(pack.id)}
              className="flex-shrink-0 p-2 text-gray-400 hover:text-red-500 dark:text-gray-500 dark:hover:text-red-400 transition-colors duration-200"
              title="Remove pack"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
              </svg>
            </button>
          </div>
        </div>
      )}
    </Draggable>
  )
}

const PackList = ({ packs, onRemovePack, onReorderPacks, onAddMore }) => {
  const fileInputRef = useRef(null)

  const handleDragEnd = useCallback((result) => {
    if (!result.destination) return
    
    const startIndex = result.source.index
    const endIndex = result.destination.index
    
    if (startIndex !== endIndex) {
      onReorderPacks(startIndex, endIndex)
    }
  }, [onReorderPacks])

  const handleAddMore = useCallback(() => {
    fileInputRef.current?.click()
  }, [])

  const handleFileSelect = useCallback((e) => {
    const files = Array.from(e.target.files)
    if (files.length > 0) {
      onAddMore(files)
    }
    e.target.value = ''
  }, [onAddMore])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white">
            Resource Packs
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mt-1">
            Drag to reorder • Higher priority packs override lower ones
          </p>
        </div>
        
        <button
          onClick={handleAddMore}
          className="btn-secondary flex items-center space-x-2"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
          </svg>
          <span>Add More</span>
        </button>
      </div>

      {/* Drag and Drop List */}
      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="packs">
          {(provided, snapshot) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className={`space-y-3 min-h-[100px] p-4 rounded-xl border-2 border-dashed transition-all duration-300 ${
                snapshot.isDraggingOver
                  ? 'border-blue-400 bg-blue-50 dark:bg-blue-900/20'
                  : 'border-gray-300 dark:border-gray-600'
              }`}
            >
              {packs.map((pack, index) => (
                <PackItem
                  key={pack.id}
                  pack={pack}
                  index={index}
                  onRemove={onRemovePack}
                />
              ))}
              {provided.placeholder}
              
              {packs.length === 0 && (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  <svg className="w-12 h-12 mx-auto mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"/>
                  </svg>
                  <p>No packs loaded yet</p>
                </div>
              )}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      {/* Summary */}
      {packs.length > 0 && (
        <div className="card p-4 bg-gray-50 dark:bg-gray-800/50">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                {packs.length}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Packs</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                {packs.reduce((sum, pack) => sum + pack.fileCount, 0)}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Total Files</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                {(packs.reduce((sum, pack) => sum + pack.size, 0) / 1024 / 1024).toFixed(1)} MB
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Total Size</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">
                {new Set(packs.map(pack => pack.type)).size === 1 ? '✓' : '⚠'}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                {new Set(packs.map(pack => pack.type)).size === 1 ? 'Compatible' : 'Mixed Types'}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept=".zip,.mcpack"
        onChange={handleFileSelect}
        className="hidden"
      />
    </div>
  )
}

export default PackList