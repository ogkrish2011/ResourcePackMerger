import React, { useState, useCallback } from 'react'

const ConflictItem = ({ conflict, onResolve }) => {
  const [selectedPack, setSelectedPack] = useState(conflict.packs[0].packId)

  const handleResolve = useCallback((packId) => {
    setSelectedPack(packId)
    onResolve(conflict.path, packId)
  }, [conflict.path, onResolve])

  const getFileExtensionIcon = (path) => {
    const ext = path.split('.').pop().toLowerCase()
    switch (ext) {
      case 'png':
      case 'jpg':
      case 'jpeg':
        return '🖼️'
      case 'json':
        return '📄'
      case 'txt':
        return '📝'
      case 'mcmeta':
        return '⚙️'
      case 'ogg':
      case 'wav':
        return '🔊'
      default:
        return '📁'
    }
  }

  return (
    <div className="card p-4 border-l-4 border-amber-500">
      <div className="space-y-4">
        {/* File Info */}
        <div className="flex items-start space-x-3">
          <div className="text-2xl">{getFileExtensionIcon(conflict.path)}</div>
          <div className="flex-1 min-w-0">
            <h4 className="font-medium text-gray-900 dark:text-white">
              File Conflict Detected
            </h4>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1 font-mono bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
              {conflict.path}
            </p>
            <p className="text-xs text-amber-600 dark:text-amber-400 mt-2">
              This file exists in multiple packs. Choose which version to keep:
            </p>
          </div>
        </div>

        {/* Pack Options */}
        <div className="space-y-2">
          {conflict.packs.map((packInfo, index) => (
            <label
              key={packInfo.packId}
              className={`flex items-center space-x-3 p-3 rounded-lg border-2 cursor-pointer transition-all duration-200 ${
                selectedPack === packInfo.packId
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                  : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
              }`}
            >
              <input
                type="radio"
                name={`conflict-${conflict.path}`}
                value={packInfo.packId}
                checked={selectedPack === packInfo.packId}
                onChange={() => handleResolve(packInfo.packId)}
                className="w-4 h-4 text-blue-600 focus:ring-blue-500"
              />
              
              <div className="flex items-center space-x-3 flex-1">
                {/* Pack Icon */}
                {packInfo.packIcon ? (
                  <img
                    src={packInfo.packIcon}
                    alt={`${packInfo.packName} icon`}
                    className="w-8 h-8 rounded object-cover"
                  />
                ) : (
                  <div className="w-8 h-8 bg-gray-400 rounded flex items-center justify-center">
                    <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h6a1 1 0 110 2H4a1 1 0 01-1-1zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z" clipRule="evenodd"/>
                    </svg>
                  </div>
                )}
                
                {/* Pack Info */}
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-900 dark:text-white truncate">
                    {packInfo.packName}
                  </p>
                  <div className="flex items-center space-x-2 text-xs text-gray-500 dark:text-gray-400">
                    <span>Priority: #{index + 1}</span>
                    <span>Size: {(packInfo.fileSize / 1024).toFixed(1)} KB</span>
                    {packInfo.lastModified && (
                      <span>Modified: {new Date(packInfo.lastModified).toLocaleDateString()}</span>
                    )}
                  </div>
                </div>

                {/* Priority Badge */}
                <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                  index === 0 
                    ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                    : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'
                }`}>
                  {index === 0 ? 'Highest Priority' : `Priority ${index + 1}`}
                </div>
              </div>
            </label>
          ))}
        </div>

        {/* Preview */}
        {conflict.preview && (
          <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <h5 className="text-sm font-medium text-gray-900 dark:text-white mb-2">
              Preview (selected version):
            </h5>
            <div className="text-xs text-gray-600 dark:text-gray-400 font-mono whitespace-pre-wrap max-h-32 overflow-y-auto">
              {conflict.preview}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

const ConflictResolver = ({ conflicts, onResolve, onCancel }) => {
  const [resolutions, setResolutions] = useState(() => {
    // Initialize with highest priority (first) pack for each conflict
    const initial = {}
    conflicts.forEach(conflict => {
      initial[conflict.path] = conflict.packs[0].packId
    })
    return initial
  })

  const handleConflictResolve = useCallback((path, packId) => {
    setResolutions(prev => ({
      ...prev,
      [path]: packId
    }))
  }, [])

  const handleResolveAll = useCallback(() => {
    onResolve(resolutions)
  }, [resolutions, onResolve])

  const handleAutoResolve = useCallback((strategy) => {
    const newResolutions = {}
    
    conflicts.forEach(conflict => {
      switch (strategy) {
        case 'priority':
          // Keep highest priority (first) pack
          newResolutions[conflict.path] = conflict.packs[0].packId
          break
        case 'largest':
          // Keep largest file
          const largestPack = conflict.packs.reduce((prev, current) => 
            (current.fileSize > prev.fileSize) ? current : prev
          )
          newResolutions[conflict.path] = largestPack.packId
          break
        case 'newest':
          // Keep newest file (if timestamp available)
          const newestPack = conflict.packs.reduce((prev, current) => 
            (current.lastModified > prev.lastModified) ? current : prev
          )
          newResolutions[conflict.path] = newestPack.packId
          break
        default:
          newResolutions[conflict.path] = conflict.packs[0].packId
      }
    })
    
    setResolutions(newResolutions)
  }, [conflicts])

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex min-h-screen items-center justify-center p-4">
        {/* Backdrop */}
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          onClick={onCancel}
        />
        
        {/* Modal */}
        <div className="relative w-full max-w-4xl bg-white dark:bg-gray-800 rounded-xl shadow-2xl animate-slide-up">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <div>
              <h2 className="text-2xl font-semibold text-gray-900 dark:text-white">
                Resolve File Conflicts
              </h2>
              <p className="text-gray-600 dark:text-gray-300 mt-1">
                {conflicts.length} file{conflicts.length !== 1 ? 's' : ''} found in multiple packs
              </p>
            </div>
            
            <button
              onClick={onCancel}
              className="p-2 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/>
              </svg>
            </button>
          </div>
          
          {/* Auto Resolve Options */}
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center space-x-4">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Quick resolve:
              </span>
              <button
                onClick={() => handleAutoResolve('priority')}
                className="text-sm px-3 py-1 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 rounded-full hover:bg-blue-200 dark:hover:bg-blue-800 transition-colors"
              >
                Keep Priority Order
              </button>
              <button
                onClick={() => handleAutoResolve('largest')}
                className="text-sm px-3 py-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 rounded-full hover:bg-green-200 dark:hover:bg-green-800 transition-colors"
              >
                Keep Largest Files
              </button>
              <button
                onClick={() => handleAutoResolve('newest')}
                className="text-sm px-3 py-1 bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200 rounded-full hover:bg-purple-200 dark:hover:bg-purple-800 transition-colors"
              >
                Keep Newest Files
              </button>
            </div>
          </div>
          
          {/* Conflicts List */}
          <div className="p-6 max-h-96 overflow-y-auto">
            <div className="space-y-6">
              {conflicts.map((conflict, index) => (
                <ConflictItem
                  key={conflict.path}
                  conflict={conflict}
                  onResolve={handleConflictResolve}
                />
              ))}
            </div>
          </div>
          
          {/* Actions */}
          <div className="flex items-center justify-end space-x-4 p-6 border-t border-gray-200 dark:border-gray-700">
            <button
              onClick={onCancel}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button
              onClick={handleResolveAll}
              className="btn-primary"
            >
              Apply Resolutions ({conflicts.length})
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ConflictResolver