import React, { useState, useRef, useCallback } from 'react'
import { saveAs } from 'file-saver'
import toast from 'react-hot-toast'

const PackEditor = ({ packData, onClose }) => {
  const [packName, setPackName] = useState(packData.name || 'Merged Pack')
  const [packDescription, setPackDescription] = useState(
    packData.description || 'A merged resource pack created with Pack Merger'
  )
  const [customIcon, setCustomIcon] = useState(null)
  const [iconPreview, setIconPreview] = useState(packData.icon || null)
  const [isDownloading, setIsDownloading] = useState(false)
  const fileInputRef = useRef(null)

  const handleIconSelect = useCallback(() => {
    fileInputRef.current?.click()
  }, [])

  const handleIconChange = useCallback((e) => {
    const file = e.target.files[0]
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast.error('Please select an image file')
        return
      }

      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast.error('Icon file must be smaller than 5MB')
        return
      }

      const reader = new FileReader()
      reader.onload = (event) => {
        const result = event.target.result
        setCustomIcon(file)
        setIconPreview(result)
      }
      reader.readAsDataURL(file)
    }
  }, [])

  const handleRemoveIcon = useCallback(() => {
    setCustomIcon(null)
    setIconPreview(packData.icon || null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }, [packData.icon])

  const handleDownload = useCallback(async () => {
    if (isDownloading) return

    setIsDownloading(true)
    
    try {
      // Update pack metadata
      const updatedPackData = {
        ...packData,
        name: packName.trim() || 'Merged Pack',
        description: packDescription.trim() || 'A merged resource pack created with Pack Merger',
        customIcon: customIcon
      }

      // Generate the final pack
      const finalZip = await generateFinalPack(updatedPackData)
      
      // Create filename
      const filename = `${packName.replace(/[^a-zA-Z0-9-_\s]/g, '').replace(/\s+/g, '-')}.zip`
      
      // Download the file
      const blob = await finalZip.generateAsync({ type: 'blob' })
      saveAs(blob, filename)
      
      toast.success('Pack downloaded successfully!')
      onClose()
      
    } catch (error) {
      console.error('Download error:', error)
      toast.error('Failed to download pack: ' + error.message)
    } finally {
      setIsDownloading(false)
    }
  }, [packData, packName, packDescription, customIcon, isDownloading, onClose])

  const generateFinalPack = async (updatedPackData) => {
    const { default: JSZip } = await import('jszip')
    const zip = new JSZip()

    // Add all files from the merged pack
    for (const [path, content] of Object.entries(updatedPackData.files)) {
      if (path === 'pack.mcmeta' || path === 'manifest.json') {
        // Skip - we'll generate new metadata
        continue
      }
      if (path === 'pack.png' || path === 'pack_icon.png') {
        // Skip - we'll handle icon separately
        continue
      }
      
      zip.file(path, content, { binary: true })
    }

    // Add custom icon if provided
    if (updatedPackData.customIcon) {
      const iconBuffer = await updatedPackData.customIcon.arrayBuffer()
      const iconName = updatedPackData.type === 'bedrock' ? 'pack_icon.png' : 'pack.png'
      zip.file(iconName, iconBuffer)
    } else if (updatedPackData.iconData) {
      // Use existing icon data
      const iconName = updatedPackData.type === 'bedrock' ? 'pack_icon.png' : 'pack.png'
      zip.file(iconName, updatedPackData.iconData, { binary: true })
    }

    // Generate appropriate metadata
    if (updatedPackData.type === 'bedrock') {
      // Generate manifest.json for Bedrock
      const manifest = {
        format_version: 2,
        header: {
          name: updatedPackData.name,
          description: updatedPackData.description,
          uuid: generateUUID(),
          version: [1, 0, 0],
          min_engine_version: updatedPackData.minEngineVersion || [1, 16, 0]
        },
        modules: [{
          type: "resources",
          uuid: generateUUID(),
          version: [1, 0, 0]
        }]
      }
      
      zip.file('manifest.json', JSON.stringify(manifest, null, 2))
      
    } else {
      // Generate pack.mcmeta for Java
      const mcmeta = {
        pack: {
          pack_format: updatedPackData.packFormat || getLatestPackFormat(),
          description: updatedPackData.description
        }
      }
      
      zip.file('pack.mcmeta', JSON.stringify(mcmeta, null, 2))
    }

    return zip
  }

  const generateUUID = () => {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0
      const v = c === 'x' ? r : (r & 0x3 | 0x8)
      return v.toString(16)
    })
  }

  const getLatestPackFormat = () => {
    // Return latest known Java pack format (as of Minecraft 1.20+)
    return 15
  }

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex min-h-screen items-center justify-center p-4">
        {/* Backdrop */}
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        />
        
        {/* Modal */}
        <div className="relative w-full max-w-2xl bg-white dark:bg-gray-800 rounded-xl shadow-2xl animate-slide-up">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <div>
              <h2 className="text-2xl font-semibold text-gray-900 dark:text-white">
                Customize Pack
              </h2>
              <p className="text-gray-600 dark:text-gray-300 mt-1">
                Edit pack details before downloading
              </p>
            </div>
            
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/>
              </svg>
            </button>
          </div>
          
          {/* Content */}
          <div className="p-6 space-y-6">
            {/* Pack Icon */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                Pack Icon
              </label>
              <div className="flex items-center space-x-4">
                <div className="relative">
                  {iconPreview ? (
                    <img
                      src={iconPreview}
                      alt="Pack icon preview"
                      className="w-16 h-16 rounded-lg object-cover shadow-md"
                    />
                  ) : (
                    <div className="w-16 h-16 bg-gradient-to-br from-gray-400 to-gray-600 rounded-lg flex items-center justify-center shadow-md">
                      <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd"/>
                      </svg>
                    </div>
                  )}
                </div>
                
                <div className="flex-1">
                  <div className="flex space-x-2">
                    <button
                      onClick={handleIconSelect}
                      className="btn-secondary text-sm"
                    >
                      Choose Icon
                    </button>
                    {customIcon && (
                      <button
                        onClick={handleRemoveIcon}
                        className="text-sm px-3 py-1 text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Recommended: 128x128 PNG image
                  </p>
                </div>
              </div>
            </div>

            {/* Pack Name */}
            <div>
              <label htmlFor="packName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Pack Name
              </label>
              <input
                id="packName"
                type="text"
                value={packName}
                onChange={(e) => setPackName(e.target.value)}
                placeholder="Enter pack name..."
                className="input-field"
                maxLength={50}
              />
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                {packName.length}/50 characters
              </p>
            </div>

            {/* Pack Description */}
            <div>
              <label htmlFor="packDescription" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Description
              </label>
              <textarea
                id="packDescription"
                value={packDescription}
                onChange={(e) => setPackDescription(e.target.value)}
                placeholder="Enter pack description..."
                rows={3}
                className="input-field resize-none"
                maxLength={200}
              />
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                {packDescription.length}/200 characters
              </p>
            </div>

            {/* Pack Info */}
            <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4">
              <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-3">
                Pack Information
              </h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600 dark:text-gray-400">Type:</span>
                  <span className="ml-2 font-medium text-gray-900 dark:text-white capitalize">
                    {packData.type}
                  </span>
                </div>
                <div>
                  <span className="text-gray-600 dark:text-gray-400">Files:</span>
                  <span className="ml-2 font-medium text-gray-900 dark:text-white">
                    {packData.fileCount}
                  </span>
                </div>
                <div>
                  <span className="text-gray-600 dark:text-gray-400">Size:</span>
                  <span className="ml-2 font-medium text-gray-900 dark:text-white">
                    {(packData.size / 1024 / 1024).toFixed(2)} MB
                  </span>
                </div>
                <div>
                  <span className="text-gray-600 dark:text-gray-400">Format:</span>
                  <span className="ml-2 font-medium text-gray-900 dark:text-white">
                    v{packData.format || (packData.type === 'java' ? getLatestPackFormat() : '2')}
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Actions */}
          <div className="flex items-center justify-end space-x-4 p-6 border-t border-gray-200 dark:border-gray-700">
            <button
              onClick={onClose}
              disabled={isDownloading}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button
              onClick={handleDownload}
              disabled={isDownloading || !packName.trim()}
              className="btn-primary flex items-center space-x-2"
            >
              {isDownloading && (
                <svg className="w-4 h-4 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                </svg>
              )}
              <span>{isDownloading ? 'Generating...' : 'Download Pack'}</span>
            </button>
          </div>

          {/* Hidden file input */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleIconChange}
            className="hidden"
          />
        </div>
      </div>
    </div>
  )
}

export default PackEditor