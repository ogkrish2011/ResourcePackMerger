import { useState, useCallback, useRef } from 'react'
import { v4 as uuidv4 } from 'uuid'
import toast from 'react-hot-toast'
import { PackProcessor } from '../utils/PackProcessor'
import { PackMerger } from '../utils/PackMerger'

export const usePackMerger = () => {
  const [packs, setPacks] = useState([])
  const [conflicts, setConflicts] = useState([])
  const [isProcessing, setIsProcessing] = useState(false)
  const [progress, setProgress] = useState({
    phase: 'idle',
    current: 0,
    total: 0,
    message: '',
    percentage: 0
  })
  
  const workerRef = useRef(null)
  const processorRef = useRef(new PackProcessor())
  const mergerRef = useRef(new PackMerger())

  const updateProgress = useCallback((update) => {
    setProgress(prev => ({
      ...prev,
      ...update,
      percentage: update.total > 0 ? Math.round((update.current / update.total) * 100) : 0
    }))
  }, [])

  const addPacks = useCallback(async (files) => {
    if (isProcessing) {
      toast.error('Please wait for current processing to complete')
      return
    }

    setIsProcessing(true)
    updateProgress({
      phase: 'reading',
      current: 0,
      total: files.length,
      message: 'Reading pack files...'
    })

    try {
      const newPacks = []
      
      for (let i = 0; i < files.length; i++) {
        const file = files[i]
        updateProgress({
          current: i + 1,
          message: `Reading ${file.name}...`
        })

        try {
          const packData = await processorRef.current.processPackFile(file)
          
          // Validate pack
          if (!packData.files || Object.keys(packData.files).length === 0) {
            toast.error(`${file.name} appears to be empty or invalid`)
            continue
          }

          newPacks.push({
            id: uuidv4(),
            name: packData.name || file.name.replace(/\.(zip|mcpack)$/i, ''),
            originalFileName: file.name,
            size: file.size,
            fileCount: Object.keys(packData.files).length,
            type: packData.type,
            format: packData.format,
            icon: packData.icon,
            files: packData.files,
            metadata: packData.metadata,
            minEngineVersion: packData.minEngineVersion
          })

          // Show progress toast for large packs
          if (Object.keys(packData.files).length > 1000) {
            toast.success(`Loaded ${file.name} (${Object.keys(packData.files).length} files)`, {
              duration: 2000
            })
          }

        } catch (error) {
          console.error(`Error processing ${file.name}:`, error)
          toast.error(`Failed to process ${file.name}: ${error.message}`)
        }
      }

      if (newPacks.length > 0) {
        setPacks(prev => [...prev, ...newPacks])
        toast.success(`Added ${newPacks.length} pack${newPacks.length !== 1 ? 's' : ''}`)
      }

    } catch (error) {
      console.error('Error adding packs:', error)
      toast.error('Failed to process packs: ' + error.message)
    } finally {
      setIsProcessing(false)
      updateProgress({
        phase: 'idle',
        current: 0,
        total: 0,
        message: '',
        percentage: 0
      })
    }
  }, [isProcessing, updateProgress])

  const removePack = useCallback((packId) => {
    setPacks(prev => prev.filter(pack => pack.id !== packId))
    setConflicts(prev => prev.filter(conflict => 
      !conflict.packs.some(pack => pack.packId === packId)
    ))
    toast.success('Pack removed')
  }, [])

  const reorderPacks = useCallback((startIndex, endIndex) => {
    setPacks(prev => {
      const newPacks = [...prev]
      const [movedPack] = newPacks.splice(startIndex, 1)
      newPacks.splice(endIndex, 0, movedPack)
      return newPacks
    })
    
    // Clear conflicts when reordering - they need to be re-analyzed
    setConflicts([])
  }, [])

  const analyzePacks = useCallback(async () => {
    if (packs.length < 2) return []

    updateProgress({
      phase: 'analyzing',
      current: 0,
      total: packs.length,
      message: 'Analyzing conflicts...'
    })

    try {
      const detectedConflicts = await mergerRef.current.analyzeConflicts(
        packs,
        (current, total, message) => {
          updateProgress({ current, total, message })
        }
      )

      setConflicts(detectedConflicts)
      return detectedConflicts

    } catch (error) {
      console.error('Error analyzing conflicts:', error)
      throw error
    }
  }, [packs, updateProgress])

  const resolveConflicts = useCallback(async (resolutions) => {
    try {
      // Apply the conflict resolutions
      mergerRef.current.setConflictResolutions(resolutions)
      setConflicts([])
      toast.success('Conflicts resolved')
    } catch (error) {
      console.error('Error resolving conflicts:', error)
      toast.error('Failed to resolve conflicts: ' + error.message)
      throw error
    }
  }, [])

  const mergePacks = useCallback(async () => {
    if (packs.length < 2) {
      toast.error('Need at least 2 packs to merge')
      return
    }

    setIsProcessing(true)

    try {
      // First analyze for conflicts if not already done
      let currentConflicts = conflicts
      if (conflicts.length === 0 && packs.length > 1) {
        currentConflicts = await analyzePacks()
        
        // If conflicts found and no resolutions set, return early
        if (currentConflicts.length > 0) {
          setIsProcessing(false)
          return null
        }
      }

      updateProgress({
        phase: 'merging',
        current: 0,
        total: packs.length,
        message: 'Merging packs...'
      })

      const mergedPack = await mergerRef.current.mergePacks(
        packs,
        (current, total, message) => {
          updateProgress({ current, total, message })
        }
      )

      updateProgress({
        phase: 'generating',
        current: 1,
        total: 1,
        message: 'Finalizing merged pack...'
      })

      toast.success('Packs merged successfully!')
      return mergedPack

    } catch (error) {
      console.error('Error merging packs:', error)
      toast.error('Failed to merge packs: ' + error.message)
      throw error
    } finally {
      setIsProcessing(false)
      updateProgress({
        phase: 'idle',
        current: 0,
        total: 0,
        message: '',
        percentage: 0
      })
    }
  }, [packs, conflicts, analyzePacks, updateProgress])

  const resetMerger = useCallback(() => {
    setPacks([])
    setConflicts([])
    setProgress({
      phase: 'idle',
      current: 0,
      total: 0,
      message: '',
      percentage: 0
    })
    
    // Reset processor and merger instances
    processorRef.current = new PackProcessor()
    mergerRef.current = new PackMerger()
    
    toast.success('Reset complete')
  }, [])

  return {
    packs,
    conflicts,
    isProcessing,
    progress,
    addPacks,
    removePack,
    reorderPacks,
    resolveConflicts,
    mergePacks,
    resetMerger
  }
}