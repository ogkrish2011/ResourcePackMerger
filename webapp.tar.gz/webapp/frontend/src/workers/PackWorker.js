// Web Worker for processing large pack files without blocking the UI

import JSZip from 'jszip'

class PackWorker {
  constructor() {
    self.onmessage = this.handleMessage.bind(this)
  }

  async handleMessage(event) {
    const { type, data, id } = event.data

    try {
      switch (type) {
        case 'PROCESS_PACK':
          await this.processPack(data, id)
          break
        
        case 'ANALYZE_CONFLICTS':
          await this.analyzeConflicts(data, id)
          break
        
        case 'MERGE_PACKS':
          await this.mergePacks(data, id)
          break
        
        default:
          this.sendError(id, `Unknown message type: ${type}`)
      }
    } catch (error) {
      this.sendError(id, error.message, error.stack)
    }
  }

  async processPack(data, id) {
    const { fileBuffer, fileName } = data
    
    this.sendProgress(id, 0, 'Reading pack file...')
    
    try {
      const zip = await JSZip.loadAsync(fileBuffer)
      const files = {}
      let packType = 'unknown'
      let packFormat = null
      let minEngineVersion = null
      let packName = fileName.replace(/\.(zip|mcpack)$/i, '')
      let packDescription = ''
      let packIcon = null

      // Get file list for progress tracking
      const fileEntries = []
      zip.forEach((relativePath, zipEntry) => {
        if (!zipEntry.dir && !relativePath.includes('__MACOSX')) {
          fileEntries.push({ path: relativePath, entry: zipEntry })
        }
      })

      this.sendProgress(id, 10, `Found ${fileEntries.length} files`)

      // Process metadata first
      const manifestFile = zip.file('manifest.json')
      const mcmetaFile = zip.file('pack.mcmeta')

      if (manifestFile) {
        packType = 'bedrock'
        try {
          const manifestContent = await manifestFile.async('string')
          const manifest = JSON.parse(manifestContent)
          
          if (manifest.header) {
            packName = manifest.header.name || packName
            packDescription = manifest.header.description || ''
            
            if (manifest.header.min_engine_version) {
              minEngineVersion = manifest.header.min_engine_version
              packFormat = manifest.header.min_engine_version[1] || 1
            }
          }
        } catch (error) {
          console.warn('Failed to parse manifest.json:', error)
        }
      } else if (mcmetaFile) {
        packType = 'java'
        try {
          const mcmetaContent = await mcmetaFile.async('string')
          const mcmeta = JSON.parse(mcmetaContent)
          
          if (mcmeta.pack) {
            packFormat = mcmeta.pack.pack_format
            packDescription = Array.isArray(mcmeta.pack.description) 
              ? mcmeta.pack.description.join(' ')
              : (mcmeta.pack.description || '')
          }
        } catch (error) {
          console.warn('Failed to parse pack.mcmeta:', error)
        }
      }

      this.sendProgress(id, 20, 'Extracting pack icon...')

      // Extract icon
      const iconFile = zip.file('pack_icon.png') || zip.file('pack.png')
      if (iconFile) {
        try {
          const iconBlob = await iconFile.async('blob')
          packIcon = await this.blobToDataURL(iconBlob)
        } catch (error) {
          console.warn('Failed to extract pack icon:', error)
        }
      }

      this.sendProgress(id, 30, 'Processing files...')

      // Process all files
      const batchSize = 50 // Process files in batches to allow progress updates
      for (let i = 0; i < fileEntries.length; i += batchSize) {
        const batch = fileEntries.slice(i, i + batchSize)
        
        await Promise.all(batch.map(async ({ path, entry }) => {
          try {
            if (this.isTextFile(path)) {
              files[path] = await entry.async('string')
            } else {
              files[path] = await entry.async('arraybuffer')
            }
          } catch (error) {
            console.warn(`Failed to process file ${path}:`, error)
          }
        }))

        const progress = 30 + ((i + batch.length) / fileEntries.length) * 60
        this.sendProgress(id, progress, `Processed ${Math.min(i + batch.length, fileEntries.length)}/${fileEntries.length} files`)
      }

      this.sendProgress(id, 95, 'Finalizing...')

      // Auto-detect type if still unknown
      if (packType === 'unknown') {
        packType = this.detectPackType(files)
      }

      const result = {
        name: packName,
        description: packDescription,
        type: packType,
        format: packFormat,
        minEngineVersion,
        icon: packIcon,
        files,
        metadata: {
          hasManifest: !!manifestFile,
          hasMcmeta: !!mcmetaFile,
          detectedType: packType
        }
      }

      this.sendProgress(id, 100, 'Complete')
      this.sendSuccess(id, result)

    } catch (error) {
      throw new Error(`Failed to process pack: ${error.message}`)
    }
  }

  async analyzeConflicts(data, id) {
    const { packs } = data
    
    if (packs.length < 2) {
      this.sendSuccess(id, [])
      return
    }

    const conflicts = []
    const fileMap = new Map()

    this.sendProgress(id, 0, 'Building file map...')

    // Build file map
    for (let i = 0; i < packs.length; i++) {
      const pack = packs[i]
      
      for (const filePath of Object.keys(pack.files)) {
        if (!fileMap.has(filePath)) {
          fileMap.set(filePath, [])
        }

        const fileSize = this.getFileSize(pack.files[filePath])
        
        fileMap.get(filePath).push({
          packId: pack.id,
          packName: pack.name,
          packIcon: pack.icon,
          fileSize,
          lastModified: pack.originalFile?.lastModified || Date.now()
        })
      }

      const progress = ((i + 1) / packs.length) * 50
      this.sendProgress(id, progress, `Analyzed ${pack.name}`)
    }

    this.sendProgress(id, 50, 'Detecting conflicts...')

    // Find conflicts
    let conflictCount = 0
    for (const [filePath, packInfos] of fileMap) {
      if (packInfos.length > 1) {
        conflicts.push({
          path: filePath,
          packs: packInfos,
          preview: await this.getFilePreview(filePath, packs, packInfos[0].packId)
        })
        conflictCount++
      }

      if (conflictCount % 10 === 0) {
        const progress = 50 + (conflictCount / fileMap.size) * 50
        this.sendProgress(id, progress, `Found ${conflicts.length} conflicts`)
      }
    }

    this.sendProgress(id, 100, `Analysis complete - ${conflicts.length} conflicts found`)
    this.sendSuccess(id, conflicts)
  }

  async mergePacks(data, id) {
    const { packs, conflictResolutions } = data
    
    if (packs.length === 0) {
      throw new Error('No packs to merge')
    }

    const mergedFiles = new Map()
    const resolutionMap = new Map(Object.entries(conflictResolutions || {}))

    let processedPacks = 0

    this.sendProgress(id, 0, 'Starting merge...')

    // Process each pack
    for (const pack of packs) {
      this.sendProgress(id, (processedPacks / packs.length) * 80, `Merging ${pack.name}...`)

      for (const [filePath, fileContent] of Object.entries(pack.files)) {
        // Skip metadata files
        if (filePath === 'pack.mcmeta' || filePath === 'manifest.json') {
          continue
        }

        // Check for conflicts
        if (mergedFiles.has(filePath)) {
          const resolvedPackId = resolutionMap.get(filePath)
          
          if (resolvedPackId && resolvedPackId === pack.id) {
            mergedFiles.set(filePath, {
              content: fileContent,
              packId: pack.id,
              packName: pack.name
            })
          }
        } else {
          mergedFiles.set(filePath, {
            content: fileContent,
            packId: pack.id,
            packName: pack.name
          })
        }
      }

      processedPacks++
    }

    this.sendProgress(id, 80, 'Building final pack structure...')

    // Build final structure
    const mergedData = {
      name: 'Merged Pack',
      description: 'A merged resource pack created with Pack Merger',
      type: this.determineMergedPackType(packs),
      format: this.determineMergedPackFormat(packs),
      minEngineVersion: this.determineMergedMinEngineVersion(packs),
      icon: packs.find(p => p.icon)?.icon || null,
      files: {},
      size: 0,
      fileCount: mergedFiles.size
    }

    for (const [filePath, fileData] of mergedFiles) {
      mergedData.files[filePath] = fileData.content
      mergedData.size += this.getFileSize(fileData.content)
    }

    this.sendProgress(id, 100, 'Merge complete')
    this.sendSuccess(id, mergedData)
  }

  // Utility methods
  isTextFile(path) {
    const textExtensions = [
      '.json', '.mcmeta', '.txt', '.md', '.lang', '.properties',
      '.cfg', '.ini', '.yml', '.yaml', '.xml', '.js', '.css',
      '.glsl', '.vsh', '.fsh', '.vert', '.frag'
    ]
    
    const ext = '.' + path.split('.').pop().toLowerCase()
    return textExtensions.includes(ext)
  }

  detectPackType(files) {
    const bedrockIndicators = [
      'manifest.json', 'pack_icon.png', 'texts/en_US.lang'
    ]
    const javaIndicators = [
      'pack.mcmeta', 'pack.png', 'assets/minecraft/', 'data/'
    ]

    const hasBedrockFiles = bedrockIndicators.some(indicator =>
      Object.keys(files).some(path => path.includes(indicator))
    )
    const hasJavaFiles = javaIndicators.some(indicator =>
      Object.keys(files).some(path => path.includes(indicator))
    )

    if (hasBedrockFiles && !hasJavaFiles) return 'bedrock'
    if (hasJavaFiles && !hasBedrockFiles) return 'java'
    return 'java'
  }

  getFileSize(content) {
    if (typeof content === 'string') {
      return new Blob([content]).size
    }
    if (content instanceof ArrayBuffer) {
      return content.byteLength
    }
    return content?.length || 0
  }

  async getFilePreview(filePath, packs, packId) {
    try {
      const pack = packs.find(p => p.id === packId)
      if (!pack || !pack.files[filePath]) return null

      const content = pack.files[filePath]
      
      if (typeof content === 'string') {
        return content.slice(0, 500) + (content.length > 500 ? '...' : '')
      }
      
      const size = content.byteLength || content.length || 0
      return `Binary file (${(size / 1024).toFixed(1)} KB)`
      
    } catch (error) {
      return `Error reading file: ${error.message}`
    }
  }

  determineMergedPackType(packs) {
    const types = [...new Set(packs.map(pack => pack.type))]
    if (types.length === 1) return types[0]
    
    const typeCounts = {}
    for (const pack of packs) {
      typeCounts[pack.type] = (typeCounts[pack.type] || 0) + 1
    }
    
    return Object.keys(typeCounts).reduce((a, b) => 
      typeCounts[a] > typeCounts[b] ? a : b
    )
  }

  determineMergedPackFormat(packs) {
    let maxFormat = 1
    for (const pack of packs) {
      if (pack.format && pack.format > maxFormat) {
        maxFormat = pack.format
      }
    }
    return maxFormat
  }

  determineMergedMinEngineVersion(packs) {
    let maxVersion = [1, 16, 0]
    for (const pack of packs) {
      if (pack.minEngineVersion && this.compareVersions(pack.minEngineVersion, maxVersion) > 0) {
        maxVersion = pack.minEngineVersion
      }
    }
    return maxVersion
  }

  compareVersions(a, b) {
    for (let i = 0; i < Math.max(a.length, b.length); i++) {
      const aVal = a[i] || 0
      const bVal = b[i] || 0
      
      if (aVal > bVal) return 1
      if (aVal < bVal) return -1
    }
    return 0
  }

  async blobToDataURL(blob) {
    return new Promise((resolve) => {
      const reader = new FileReader()
      reader.onload = () => resolve(reader.result)
      reader.readAsDataURL(blob)
    })
  }

  sendProgress(id, percentage, message) {
    self.postMessage({
      type: 'PROGRESS',
      id,
      data: { percentage, message }
    })
  }

  sendSuccess(id, result) {
    self.postMessage({
      type: 'SUCCESS',
      id,
      data: result
    })
  }

  sendError(id, message, stack = null) {
    self.postMessage({
      type: 'ERROR',
      id,
      data: { message, stack }
    })
  }
}

// Initialize worker
new PackWorker()