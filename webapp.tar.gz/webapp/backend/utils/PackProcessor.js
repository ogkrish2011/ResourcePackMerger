const JSZip = require('jszip')
const { v4: uuidv4 } = require('uuid')

class PackProcessor {
  constructor() {
    this.supportedExtensions = ['.zip', '.mcpack']
  }

  async processPackBuffer(buffer, fileName) {
    if (!this.isValidPackFile(fileName)) {
      throw new Error(`Unsupported file type. Please use ${this.supportedExtensions.join(', ')} files.`)
    }

    try {
      const zip = await JSZip.loadAsync(buffer)
      return await this.extractPackData(zip, fileName)
    } catch (error) {
      throw new Error(`Failed to read pack file: ${error.message}`)
    }
  }

  async getPackInfo(buffer, fileName) {
    const zip = await JSZip.loadAsync(buffer)
    
    // Extract metadata only
    const manifestFile = zip.file('manifest.json')
    const mcmetaFile = zip.file('pack.mcmeta')
    
    let packType = 'unknown'
    let packFormat = null
    let minEngineVersion = null
    let packName = fileName.replace(/\.(zip|mcpack)$/i, '')
    let packDescription = ''
    
    if (manifestFile) {
      packType = 'bedrock'
      try {
        const manifestContent = await manifestFile.async('string')
        const manifest = JSON.parse(manifestContent)
        
        if (manifest.header) {
          packName = manifest.header.name || packName
          packDescription = manifest.header.description || ''
          
          if (manifest.header.min_engine_version) {
            minEngineVersion = manifest.header.min_engine_version
            packFormat = manifest.header.min_engine_version[1] || 1
          }
        }
      } catch (error) {
        console.warn('Failed to parse manifest.json:', error)
      }
    } else if (mcmetaFile) {
      packType = 'java'
      try {
        const mcmetaContent = await mcmetaFile.async('string')
        const mcmeta = JSON.parse(mcmetaContent)
        
        if (mcmeta.pack) {
          packFormat = mcmeta.pack.pack_format
          packDescription = Array.isArray(mcmeta.pack.description) 
            ? mcmeta.pack.description.join(' ')
            : (mcmeta.pack.description || '')
        }
      } catch (error) {
        console.warn('Failed to parse pack.mcmeta:', error)
      }
    }

    // Count files
    let fileCount = 0
    zip.forEach((relativePath, zipEntry) => {
      if (!zipEntry.dir && !relativePath.includes('__MACOSX')) {
        fileCount++
      }
    })

    return {
      name: packName,
      description: packDescription,
      type: packType,
      format: packFormat,
      minEngineVersion,
      fileCount,
      hasManifest: !!manifestFile,
      hasMcmeta: !!mcmetaFile
    }
  }

  async validatePack(buffer, fileName) {
    const issues = []
    const warnings = []
    let isValid = true
    let packType = 'unknown'

    try {
      const zip = await JSZip.loadAsync(buffer)
      
      const manifestFile = zip.file('manifest.json')
      const mcmetaFile = zip.file('pack.mcmeta')

      if (!manifestFile && !mcmetaFile) {
        issues.push('No pack.mcmeta or manifest.json found')
        isValid = false
      }

      if (manifestFile && mcmetaFile) {
        warnings.push('Contains both manifest.json and pack.mcmeta - Bedrock format will be used')
      }

      if (manifestFile) {
        packType = 'bedrock'
        try {
          const manifestContent = await manifestFile.async('string')
          const manifest = JSON.parse(manifestContent)
          
          if (!manifest.header) {
            issues.push('manifest.json missing required header section')
            isValid = false
          } else {
            if (!manifest.header.uuid || !this.isValidUUID(manifest.header.uuid)) {
              warnings.push('Invalid or missing UUID in header')
            }
            if (!manifest.header.version) {
              warnings.push('Missing version in header')
            }
          }

          if (!manifest.modules || manifest.modules.length === 0) {
            issues.push('manifest.json missing required modules section')
            isValid = false
          }
          
        } catch (error) {
          issues.push(`Invalid manifest.json: ${error.message}`)
          isValid = false
        }
      }

      if (mcmetaFile && !manifestFile) {
        packType = 'java'
        try {
          const mcmetaContent = await mcmetaFile.async('string')
          const mcmeta = JSON.parse(mcmetaContent)
          
          if (!mcmeta.pack) {
            issues.push('pack.mcmeta missing required pack section')
            isValid = false
          } else {
            if (!mcmeta.pack.pack_format) {
              warnings.push('Missing pack_format in pack.mcmeta')
            }
            if (!mcmeta.pack.description) {
              warnings.push('Missing description in pack.mcmeta')
            }
          }
          
        } catch (error) {
          issues.push(`Invalid pack.mcmeta: ${error.message}`)
          isValid = false
        }
      }

      // Check for empty pack
      let fileCount = 0
      zip.forEach((relativePath, zipEntry) => {
        if (!zipEntry.dir && !relativePath.includes('__MACOSX')) {
          fileCount++
        }
      })

      if (fileCount < 2) {
        warnings.push('Pack appears to be mostly empty')
      }

    } catch (error) {
      issues.push(`Failed to read pack: ${error.message}`)
      isValid = false
    }

    return {
      isValid,
      issues,
      warnings,
      packType
    }
  }

  async generateFinalPack(packData, metadata) {
    const zip = new JSZip()

    // Add custom icon if provided
    if (metadata.customIcon) {
      const iconName = packData.type === 'bedrock' ? 'pack_icon.png' : 'pack.png'
      zip.file(iconName, metadata.customIcon)
    } else if (packData.iconData) {
      const iconName = packData.type === 'bedrock' ? 'pack_icon.png' : 'pack.png'
      zip.file(iconName, packData.iconData)
    }

    // Add all files except metadata
    for (const [filePath, fileData] of Object.entries(packData.files)) {
      if (filePath === 'pack.mcmeta' || filePath === 'manifest.json') {
        continue // Skip - we'll generate new metadata
      }
      
      if (filePath === 'pack.png' || filePath === 'pack_icon.png') {
        continue // Skip - icon handled above
      }

      if (fileData.type === 'binary') {
        zip.file(filePath, Buffer.from(fileData.data, 'base64'))
      } else {
        zip.file(filePath, fileData.data)
      }
    }

    // Generate appropriate metadata
    if (packData.type === 'bedrock') {
      const manifest = {
        format_version: 2,
        header: {
          name: metadata.name || 'Merged Pack',
          description: metadata.description || 'A merged resource pack',
          uuid: this.generateUUID(),
          version: [1, 0, 0],
          min_engine_version: packData.minEngineVersion || [1, 16, 0]
        },
        modules: [{
          type: "resources",
          uuid: this.generateUUID(),
          version: [1, 0, 0]
        }]
      }
      
      zip.file('manifest.json', JSON.stringify(manifest, null, 2))
    } else {
      const mcmeta = {
        pack: {
          pack_format: packData.format || 15,
          description: metadata.description || 'A merged resource pack'
        }
      }
      
      zip.file('pack.mcmeta', JSON.stringify(mcmeta, null, 2))
    }

    return await zip.generateAsync({ type: 'nodebuffer' })
  }

  isValidPackFile(fileName) {
    return this.supportedExtensions.some(ext => 
      fileName.toLowerCase().endsWith(ext)
    )
  }

  async extractPackData(zip, fileName) {
    const files = {}
    let packType = 'unknown'
    let packFormat = null
    let minEngineVersion = null
    let packName = fileName.replace(/\.(zip|mcpack)$/i, '')
    let packDescription = ''
    let packIcon = null

    // Extract metadata
    const manifestFile = zip.file('manifest.json')
    const mcmetaFile = zip.file('pack.mcmeta')

    if (manifestFile) {
      packType = 'bedrock'
      try {
        const manifestContent = await manifestFile.async('string')
        const manifest = JSON.parse(manifestContent)
        
        if (manifest.header) {
          packName = manifest.header.name || packName
          packDescription = manifest.header.description || ''
          
          if (manifest.header.min_engine_version) {
            minEngineVersion = manifest.header.min_engine_version
            packFormat = manifest.header.min_engine_version[1] || 1
          }
        }
      } catch (error) {
        console.warn('Failed to parse manifest.json:', error)
      }
    } else if (mcmetaFile) {
      packType = 'java'
      try {
        const mcmetaContent = await mcmetaFile.async('string')
        const mcmeta = JSON.parse(mcmetaContent)
        
        if (mcmeta.pack) {
          packFormat = mcmeta.pack.pack_format
          packDescription = Array.isArray(mcmeta.pack.description) 
            ? mcmeta.pack.description.join(' ')
            : (mcmeta.pack.description || '')
        }
      } catch (error) {
        console.warn('Failed to parse pack.mcmeta:', error)
      }
    }

    // Extract icon
    const iconFile = zip.file('pack_icon.png') || zip.file('pack.png')
    if (iconFile) {
      try {
        const iconBuffer = await iconFile.async('arraybuffer')
        const iconBase64 = Buffer.from(iconBuffer).toString('base64')
        packIcon = `data:image/png;base64,${iconBase64}`
      } catch (error) {
        console.warn('Failed to extract pack icon:', error)
      }
    }

    // Extract all files
    const filePromises = []
    
    zip.forEach((relativePath, zipEntry) => {
      if (zipEntry.dir || relativePath.includes('__MACOSX')) {
        return
      }

      filePromises.push(
        this.processZipEntry(relativePath, zipEntry)
          .then(result => {
            if (result !== null) {
              files[relativePath] = result
            }
          })
          .catch(error => {
            console.warn(`Failed to process file ${relativePath}:`, error)
          })
      )
    })

    await Promise.all(filePromises)

    if (packType === 'unknown') {
      packType = this.detectPackType(files)
    }

    return {
      name: packName,
      description: packDescription,
      type: packType,
      format: packFormat,
      minEngineVersion,
      icon: packIcon,
      files,
      fileCount: Object.keys(files).length,
      metadata: {
        hasManifest: !!manifestFile,
        hasMcmeta: !!mcmetaFile,
        detectedType: packType
      }
    }
  }

  async processZipEntry(path, zipEntry) {
    try {
      if (this.isTextFile(path)) {
        return await zipEntry.async('string')
      }
      return await zipEntry.async('arraybuffer')
    } catch (error) {
      console.warn(`Failed to read file ${path}:`, error)
      return null
    }
  }

  isTextFile(path) {
    const textExtensions = [
      '.json', '.mcmeta', '.txt', '.md', '.lang', '.properties',
      '.cfg', '.ini', '.yml', '.yaml', '.xml', '.js', '.css',
      '.glsl', '.vsh', '.fsh', '.vert', '.frag'
    ]
    
    const ext = '.' + path.split('.').pop().toLowerCase()
    return textExtensions.includes(ext)
  }

  detectPackType(files) {
    const bedrockIndicators = [
      'manifest.json', 'pack_icon.png', 'texts/en_US.lang'
    ]
    const javaIndicators = [
      'pack.mcmeta', 'pack.png', 'assets/minecraft/', 'data/'
    ]

    const hasBedrockFiles = bedrockIndicators.some(indicator =>
      Object.keys(files).some(path => path.includes(indicator))
    )
    const hasJavaFiles = javaIndicators.some(indicator =>
      Object.keys(files).some(path => path.includes(indicator))
    )

    if (hasBedrockFiles && !hasJavaFiles) return 'bedrock'
    if (hasJavaFiles && !hasBedrockFiles) return 'java'
    return 'java'
  }

  isValidUUID(uuid) {
    if (!uuid || typeof uuid !== 'string') return false
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
    return uuidRegex.test(uuid)
  }

  generateUUID() {
    return uuidv4()
  }
}

module.exports = PackProcessor