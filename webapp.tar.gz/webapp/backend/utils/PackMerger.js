class PackMerger {
  constructor() {
    this.conflictResolutions = new Map()
  }

  async analyzeConflicts(packs) {
    if (packs.length < 2) return []

    const conflicts = []
    const fileMap = new Map()

    // Build file map
    for (const pack of packs) {
      for (const filePath of Object.keys(pack.files)) {
        if (!fileMap.has(filePath)) {
          fileMap.set(filePath, [])
        }

        const fileSize = this.getFileSize(pack.files[filePath])
        
        fileMap.get(filePath).push({
          packId: pack.id,
          packName: pack.name,
          packIcon: pack.icon,
          fileSize,
          lastModified: Date.now() // Server doesn't have access to original file timestamps
        })
      }
    }

    // Find conflicts
    for (const [filePath, packInfos] of fileMap) {
      if (packInfos.length > 1) {
        conflicts.push({
          path: filePath,
          packs: packInfos,
          preview: await this.getFilePreview(filePath, packs, packInfos[0].packId)
        })
      }
    }

    return conflicts
  }

  async getFilePreview(filePath, packs, packId) {
    try {
      const pack = packs.find(p => p.id === packId)
      if (!pack || !pack.files[filePath]) return null

      const content = pack.files[filePath]
      
      if (typeof content === 'string') {
        return content.slice(0, 500) + (content.length > 500 ? '...' : '')
      }
      
      if (content instanceof ArrayBuffer) {
        const size = content.byteLength
        return `Binary file (${(size / 1024).toFixed(1)} KB)`
      }

      return `File (${JSON.stringify(content).length} bytes)`
      
    } catch (error) {
      return `Error reading file: ${error.message}`
    }
  }

  getFileSize(content) {
    if (typeof content === 'string') {
      return Buffer.byteLength(content, 'utf8')
    }
    if (content instanceof ArrayBuffer) {
      return content.byteLength
    }
    if (content && typeof content === 'object' && content.data) {
      // Handle serialized format from frontend
      if (content.type === 'binary') {
        return Buffer.from(content.data, 'base64').length
      } else {
        return Buffer.byteLength(content.data, 'utf8')
      }
    }
    return 0
  }

  setConflictResolutions(resolutions) {
    this.conflictResolutions.clear()
    for (const [filePath, packId] of Object.entries(resolutions)) {
      this.conflictResolutions.set(filePath, packId)
    }
  }

  async mergePacks(packs, options = {}) {
    if (packs.length === 0) {
      throw new Error('No packs to merge')
    }

    if (packs.length === 1) {
      return this.prepareSinglePackForEditor(packs[0])
    }

    const mergedFiles = new Map()
    const mergedData = {
      name: options.name || 'Merged Pack',
      description: options.description || 'A merged resource pack created with Pack Merger',
      type: this.determineMergedPackType(packs),
      format: this.determineMergedPackFormat(packs),
      minEngineVersion: this.determineMergedMinEngineVersion(packs),
      icon: null,
      iconData: null,
      files: {},
      size: 0,
      fileCount: 0
    }

    // Set icon from first pack with an icon
    const packWithIcon = packs.find(pack => pack.icon)
    if (packWithIcon) {
      mergedData.icon = packWithIcon.icon
      
      const iconPath = packWithIcon.type === 'bedrock' ? 'pack_icon.png' : 'pack.png'
      if (packWithIcon.files[iconPath]) {
        mergedData.iconData = packWithIcon.files[iconPath]
      }
    }

    // Merge files with priority (first pack wins for conflicts unless resolved)
    for (const pack of packs) {
      for (const [filePath, fileContent] of Object.entries(pack.files)) {
        // Skip metadata files
        if (filePath === 'pack.mcmeta' || filePath === 'manifest.json') {
          continue
        }

        // Check for conflicts
        if (mergedFiles.has(filePath)) {
          const resolvedPackId = this.conflictResolutions.get(filePath)
          
          if (resolvedPackId && resolvedPackId === pack.id) {
            mergedFiles.set(filePath, {
              content: fileContent,
              packId: pack.id,
              packName: pack.name
            })
          }
        } else {
          mergedFiles.set(filePath, {
            content: fileContent,
            packId: pack.id,
            packName: pack.name
          })
        }
      }
    }

    // Convert to final format
    for (const [filePath, fileData] of mergedFiles) {
      mergedData.files[filePath] = fileData.content
      mergedData.size += this.getFileSize(fileData.content)
    }

    mergedData.fileCount = mergedFiles.size

    return mergedData
  }

  determineMergedPackType(packs) {
    const types = [...new Set(packs.map(pack => pack.type))]
    
    if (types.length === 1) {
      return types[0]
    }
    
    // Mixed types - use most common
    const typeCounts = {}
    for (const pack of packs) {
      typeCounts[pack.type] = (typeCounts[pack.type] || 0) + 1
    }
    
    return Object.keys(typeCounts).reduce((a, b) => 
      typeCounts[a] > typeCounts[b] ? a : b
    )
  }

  determineMergedPackFormat(packs) {
    let maxFormat = 1
    
    for (const pack of packs) {
      if (pack.format && pack.format > maxFormat) {
        maxFormat = pack.format
      }
    }
    
    return maxFormat
  }

  determineMergedMinEngineVersion(packs) {
    let maxVersion = [1, 16, 0]
    
    for (const pack of packs) {
      if (pack.minEngineVersion && this.compareVersions(pack.minEngineVersion, maxVersion) > 0) {
        maxVersion = pack.minEngineVersion
      }
    }
    
    return maxVersion
  }

  compareVersions(a, b) {
    for (let i = 0; i < Math.max(a.length, b.length); i++) {
      const aVal = a[i] || 0
      const bVal = b[i] || 0
      
      if (aVal > bVal) return 1
      if (aVal < bVal) return -1
    }
    
    return 0
  }

  prepareSinglePackForEditor(pack) {
    return {
      name: pack.name,
      description: pack.description || 'Resource pack processed with Pack Merger',
      type: pack.type,
      format: pack.format,
      minEngineVersion: pack.minEngineVersion,
      icon: pack.icon,
      iconData: pack.files[pack.type === 'bedrock' ? 'pack_icon.png' : 'pack.png'] || null,
      files: { ...pack.files },
      size: this.calculateTotalSize(pack.files),
      fileCount: Object.keys(pack.files).length
    }
  }

  calculateTotalSize(files) {
    let total = 0
    for (const content of Object.values(files)) {
      total += this.getFileSize(content)
    }
    return total
  }

  validatePackCompatibility(packs) {
    const issues = []
    
    const types = [...new Set(packs.map(pack => pack.type))]
    if (types.length > 1) {
      issues.push({
        type: 'warning',
        message: `Mixed pack types detected: ${types.join(', ')}. The merged pack will use the most common type.`
      })
    }
    
    const formats = packs.map(pack => pack.format).filter(f => f != null)
    if (formats.length > 1) {
      const minFormat = Math.min(...formats)
      const maxFormat = Math.max(...formats)
      
      if (maxFormat - minFormat > 2) {
        issues.push({
          type: 'warning',
          message: `Large format version difference detected (${minFormat} to ${maxFormat}). Some features may not work correctly.`
        })
      }
    }
    
    return issues
  }

  dispose() {
    this.conflictResolutions.clear()
  }
}

module.exports = PackMerger