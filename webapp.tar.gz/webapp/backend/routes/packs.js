const express = require('express')
const multer = require('multer')
const { v4: uuidv4 } = require('uuid')
const PackProcessor = require('../utils/PackProcessor')
const PackMerger = require('../utils/PackMerger')

const router = express.Router()

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB per file
    files: 10 // Maximum 10 files per request
  },
  fileFilter: (req, file, cb) => {
    const allowedExtensions = ['.zip', '.mcpack']
    const fileExtension = '.' + file.originalname.split('.').pop().toLowerCase()
    
    if (allowedExtensions.includes(fileExtension)) {
      cb(null, true)
    } else {
      cb(new Error('Only .zip and .mcpack files are allowed'), false)
    }
  }
})

// Process individual pack files
router.post('/process', upload.array('packs', 10), async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No files provided',
        message: 'Please upload at least one pack file'
      })
    }

    const processor = new PackProcessor()
    const processedPacks = []
    const errors = []

    for (const file of req.files) {
      try {
        const packData = await processor.processPackBuffer(
          file.buffer, 
          file.originalname
        )
        
        processedPacks.push({
          id: uuidv4(),
          originalName: file.originalname,
          size: file.size,
          ...packData
        })
      } catch (error) {
        errors.push({
          filename: file.originalname,
          error: error.message
        })
      }
    }

    res.json({
      success: true,
      processedPacks,
      errors: errors.length > 0 ? errors : undefined,
      message: `Successfully processed ${processedPacks.length} of ${req.files.length} packs`
    })

  } catch (error) {
    console.error('Pack processing error:', error)
    res.status(500).json({
      error: 'Processing failed',
      message: error.message
    })
  }
})

// Analyze conflicts between packs
router.post('/analyze-conflicts', async (req, res) => {
  try {
    const { packs } = req.body

    if (!packs || !Array.isArray(packs) || packs.length < 2) {
      return res.status(400).json({
        error: 'Invalid packs data',
        message: 'Please provide at least 2 packs to analyze'
      })
    }

    const merger = new PackMerger()
    const conflicts = await merger.analyzeConflicts(packs)

    res.json({
      success: true,
      conflicts,
      conflictCount: conflicts.length,
      message: conflicts.length > 0 
        ? `Found ${conflicts.length} file conflicts`
        : 'No conflicts detected'
    })

  } catch (error) {
    console.error('Conflict analysis error:', error)
    res.status(500).json({
      error: 'Analysis failed',
      message: error.message
    })
  }
})

// Merge multiple packs
router.post('/merge', async (req, res) => {
  try {
    const { packs, conflictResolutions, options } = req.body

    if (!packs || !Array.isArray(packs) || packs.length === 0) {
      return res.status(400).json({
        error: 'Invalid packs data',
        message: 'Please provide at least one pack to merge'
      })
    }

    const merger = new PackMerger()
    
    // Set conflict resolutions if provided
    if (conflictResolutions) {
      merger.setConflictResolutions(conflictResolutions)
    }

    const mergedPack = await merger.mergePacks(packs, options)

    // Convert ArrayBuffers to Base64 for JSON transport
    const serializedFiles = {}
    for (const [path, content] of Object.entries(mergedPack.files)) {
      if (content instanceof ArrayBuffer) {
        serializedFiles[path] = {
          type: 'binary',
          data: Buffer.from(content).toString('base64')
        }
      } else {
        serializedFiles[path] = {
          type: 'text',
          data: content
        }
      }
    }

    res.json({
      success: true,
      mergedPack: {
        ...mergedPack,
        files: serializedFiles
      },
      message: `Successfully merged ${packs.length} packs`
    })

  } catch (error) {
    console.error('Pack merging error:', error)
    res.status(500).json({
      error: 'Merge failed',
      message: error.message
    })
  }
})

// Generate final pack with custom metadata
router.post('/generate', async (req, res) => {
  try {
    const { packData, metadata } = req.body

    if (!packData || !packData.files) {
      return res.status(400).json({
        error: 'Invalid pack data',
        message: 'Pack data with files is required'
      })
    }

    const processor = new PackProcessor()
    
    // Generate the final pack zip
    const zipBuffer = await processor.generateFinalPack(packData, metadata)
    
    // Send as binary response
    res.set({
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="${metadata?.name || 'merged-pack'}.zip"`,
      'Content-Length': zipBuffer.length
    })
    
    res.send(zipBuffer)

  } catch (error) {
    console.error('Pack generation error:', error)
    res.status(500).json({
      error: 'Generation failed',
      message: error.message
    })
  }
})

// Validate pack files
router.post('/validate', upload.array('packs', 10), async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No files provided',
        message: 'Please upload at least one pack file'
      })
    }

    const processor = new PackProcessor()
    const validationResults = []

    for (const file of req.files) {
      try {
        const validation = await processor.validatePack(file.buffer, file.originalname)
        validationResults.push({
          filename: file.originalname,
          valid: validation.isValid,
          issues: validation.issues,
          warnings: validation.warnings,
          type: validation.packType
        })
      } catch (error) {
        validationResults.push({
          filename: file.originalname,
          valid: false,
          issues: [error.message],
          warnings: []
        })
      }
    }

    const validCount = validationResults.filter(r => r.valid).length

    res.json({
      success: true,
      validationResults,
      summary: {
        total: req.files.length,
        valid: validCount,
        invalid: req.files.length - validCount
      },
      message: `${validCount} of ${req.files.length} packs are valid`
    })

  } catch (error) {
    console.error('Pack validation error:', error)
    res.status(500).json({
      error: 'Validation failed',
      message: error.message
    })
  }
})

// Get pack information without processing files
router.post('/info', upload.array('packs', 10), async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No files provided',
        message: 'Please upload at least one pack file'
      })
    }

    const processor = new PackProcessor()
    const packInfos = []

    for (const file of req.files) {
      try {
        const info = await processor.getPackInfo(file.buffer, file.originalname)
        packInfos.push({
          filename: file.originalname,
          size: file.size,
          ...info
        })
      } catch (error) {
        packInfos.push({
          filename: file.originalname,
          size: file.size,
          error: error.message
        })
      }
    }

    res.json({
      success: true,
      packs: packInfos,
      message: `Retrieved information for ${packInfos.length} packs`
    })

  } catch (error) {
    console.error('Pack info error:', error)
    res.status(500).json({
      error: 'Info retrieval failed',
      message: error.message
    })
  }
})

module.exports = router