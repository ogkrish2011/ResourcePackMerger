# Minecraft Pack Merger 🎮

A modern, full-featured web application for merging Minecraft resource packs with advanced conflict resolution, built-in editor, and automatic manifest normalization.

![Minecraft Pack Merger](https://img.shields.io/badge/Minecraft-Pack%20Merger-green?style=for-the-badge&logo=minecraft)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge)](https://opensource.org/licenses/MIT)
[![Node.js](https://img.shields.io/badge/Node.js-20.x-green?style=for-the-badge&logo=node.js)](https://nodejs.org/)
[![React](https://img.shields.io/badge/React-18.x-blue?style=for-the-badge&logo=react)](https://reactjs.org/)

## ✨ Features

### 🚀 Core Functionality
- **Drag & Drop Interface** - Intuitive file upload with visual feedback
- **Smart Conflict Detection** - Automatic detection and resolution of file conflicts
- **Built-in Pack Editor** - Edit pack name, description, and icon before download
- **Manifest Normalization** - Automatic fixing of pack.mcmeta and manifest.json files
- **No File Size Limit** - Handle large packs smoothly with Web Workers and streaming
- **Offline Processing** - Everything runs locally in the browser (frontend-only mode)

### 🎨 Modern UI/UX
- **Clean, Responsive Design** - Built with Tailwind CSS
- **Dark/Light Mode Toggle** - Automatic system preference detection
- **Progress Indicators** - Real-time progress bars and status messages
- **Beginner-Friendly** - Clear instructions and visual cues
- **Success Notifications** - Toast notifications for user feedback

### ⚡ Technical Excellence
- **Web Workers** - Non-blocking file processing for large packs
- **Modular Architecture** - Well-commented, easily extensible code
- **Full-Stack Support** - Optional Node.js backend for enhanced features
- **Static Site Ready** - Deployable to GitHub Pages, Netlify, Vercel
- **Performance Optimized** - Efficient memory usage and streaming support

## 🎯 Supported Pack Types

- ✅ **Java Edition** - Resource packs with `pack.mcmeta`
- ✅ **Bedrock Edition** - Resource packs with `manifest.json`
- ✅ **Mixed Packs** - Automatic type detection and conversion
- ✅ **All Formats** - `.zip` and `.mcpack` files

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ 
- npm or yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/minecraft-pack-merger.git
   cd minecraft-pack-merger
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development servers**
   ```bash
   npm run dev
   ```

4. **Open your browser**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:5000

### Production Deployment

1. **Build the application**
   ```bash
   npm run build
   ```

2. **Start with PM2 (recommended)**
   ```bash
   npm run deploy
   ```

3. **Manual start**
   ```bash
   npm start
   ```

## 📁 Project Structure

```
minecraft-pack-merger/
├── frontend/                 # React frontend application
│   ├── src/
│   │   ├── components/      # React components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── utils/          # Utility functions
│   │   ├── workers/        # Web Workers
│   │   └── App.jsx         # Main application component
│   ├── public/             # Static assets
│   └── package.json        # Frontend dependencies
├── backend/                # Node.js backend API
│   ├── routes/             # API route handlers
│   ├── utils/              # Backend utilities
│   ├── middleware/         # Express middleware
│   └── server.js           # Main server file
├── .github/workflows/      # GitHub Actions CI/CD
├── ecosystem.config.js     # PM2 configuration
└── package.json           # Root package configuration
```

## 🔧 Configuration

### Environment Variables

Create a `.env` file in the root directory:

```env
NODE_ENV=production
PORT=5000
CORS_ORIGINS=https://yourdomain.com
RATE_LIMIT_MAX_REQUESTS=100
MAX_FILE_SIZE_MB=100
```

### PM2 Configuration

The included `ecosystem.config.js` provides production-ready PM2 settings:

- **Auto-restart** on crashes
- **Memory limits** (1GB)
- **Log management** with rotation
- **Environment-specific** configurations

## 🛠️ API Documentation

### Endpoints

- `GET /api/health` - Health check
- `POST /api/packs/process` - Process pack files
- `POST /api/packs/merge` - Merge multiple packs
- `POST /api/packs/analyze-conflicts` - Detect conflicts
- `POST /api/packs/validate` - Validate pack structure

### Example Usage

```javascript
// Process pack files
const formData = new FormData()
formData.append('packs', file1)
formData.append('packs', file2)

const response = await fetch('/api/packs/process', {
  method: 'POST',
  body: formData
})

const result = await response.json()
```

## 🎮 How to Use

### Basic Pack Merging

1. **Upload Packs** - Drag and drop or browse for `.zip`/`.mcpack` files
2. **Reorder Priority** - Drag packs to set merge priority (higher = overrides lower)
3. **Review Conflicts** - Resolve any file conflicts that are detected
4. **Customize Pack** - Edit name, description, and icon
5. **Download** - Get your merged pack instantly

### Advanced Features

- **Conflict Resolution** - Choose which pack's version to keep for conflicting files
- **Automatic Fixes** - Manifest normalization ensures no in-game errors
- **Batch Processing** - Handle multiple large packs simultaneously
- **Format Conversion** - Automatically handles Java ↔ Bedrock differences

## 🚀 Deployment Options

### Static Site Hosting (Frontend Only)

**GitHub Pages**
```bash
npm run build
# Deploy frontend/dist to gh-pages branch
```

**Netlify**
- Build command: `npm run build:frontend`
- Publish directory: `frontend/dist`

**Vercel**
- Framework: React
- Build command: `npm run build:frontend`
- Output directory: `frontend/dist`

### Full-Stack Hosting

**VPS/Dedicated Server**
```bash
git clone <repository>
npm install
npm run build
npm run start:pm2
```

**Docker** (create Dockerfile)
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 5000
CMD ["npm", "start"]
```

## 🧪 Testing

```bash
# Run frontend tests
cd frontend && npm test

# Run backend tests
cd backend && npm test

# Run all tests
npm test
```

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Guidelines

- Follow the existing code style
- Add tests for new features
- Update documentation as needed
- Ensure all tests pass
- Use conventional commit messages

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Minecraft** by Mojang Studios
- **JSZip** for client-side ZIP handling
- **React** and **Tailwind CSS** for the modern UI
- **Node.js** and **Express** for the backend API

## 📞 Support

- **Issues**: [GitHub Issues](https://github.com/yourusername/minecraft-pack-merger/issues)
- **Discussions**: [GitHub Discussions](https://github.com/yourusername/minecraft-pack-merger/discussions)
- **Email**: your.email@example.com

---

**Made with ❤️ for the Minecraft community**